import { Component, OnInit } from '@angular/core';
import { TicketManagementService } from './ticket-management.service';
import { Status, Ticket, Type, User, StatusType } from './ticket.model';
import { forkJoin } from 'rxjs';
import { NotificationService } from '../services/notification.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-ticket-management',
  templateUrl: './ticket-management.component.html',
  styleUrls: ['./ticket-management.component.scss']
})
export class TicketManagementComponent implements OnInit {
  userColor: any;

  constructor(private ticketService: TicketManagementService, private notificationService: NotificationService) { }
  selectedTab: number = 0;
  tickets: Ticket[] = [];
  tasks: Ticket[] = [];
  bugs: Ticket[] = [];
  user: User = new User;
  completedList: Ticket[] = [];
  inProgressList: Ticket[] = [];
  notStartedList: Ticket[] = [];
  status: Status[] = [];
  tabGroups: { tabIndex: number, isActive: boolean }[] = [{ tabIndex: 0, isActive: true },
  { tabIndex: 1, isActive: true }, { tabIndex: 2, isActive: true },
  { tabIndex: 3, isActive: true }, { tabIndex: 4, isActive: true }]
  statusColor = { 1: '#5cb85c', 2: '#337ab7', 3: '#d9534f' };
  ngOnInit() {
    if (sessionStorage.getItem('tab')) {
      this.selectedTab = parseInt(sessionStorage.getItem('tab'));
    }
    if (sessionStorage.getItem('tabGroup')) {
      this.tabGroups = JSON.parse(sessionStorage.getItem('tabGroup'));
    }
    this.getCombineResult();
  }

  groupTabClicked(event) {
    this.selectedTab = event.index;
    sessionStorage.setItem('tab', this.selectedTab.toString());
  }

  tabClick(tabIndex) {
    if (tabIndex == this.selectedTab) {
      this.tabGroups.find(x => x.tabIndex == tabIndex).isActive = !this.tabGroups.find(x => x.tabIndex == tabIndex).isActive;
      sessionStorage.setItem('tabGroup', JSON.stringify(this.tabGroups));
    }
  }

  tabStatus(index) {
    return this.tabGroups.find(x => x.tabIndex == index).isActive;
  }

  changeStatus(event, ticket: Ticket) {
    event.stopPropagation;
    let maintainValue = ticket.status;
    ticket.status = event.value;
    this.tickets.find(x => x.id == ticket.id).status = event.value;
    this.ticketService.updateTicket(ticket).subscribe(res => {
      this.tickets.find(x => x.id == res.id).color = this.statusColor[res.status];
      this.filteredData();
      this.notificationService.showSuccess('status updated for id: ' + res.id);
    },
      err => {
        this.tickets.find(x => x.id == ticket.id).status = maintainValue;
        console.log(err.error);
      });
  }

  getCombineResult() {
    forkJoin({ user: this.ticketService.getUser(), status: this.ticketService.getStatus(), tickets: this.ticketService.getTickets() }).subscribe(res => {
      this.user = res.user instanceof HttpErrorResponse ? new User : res.user[0];
      this.status = res.status instanceof HttpErrorResponse ? [] : res.status;
      this.tickets = res.tickets instanceof HttpErrorResponse ? [] : res.tickets;
      if (this.tickets.length > 0) {
        this.tickets.forEach(e => {
          e['color'] = this.statusColor[e.status];
        });
        this.tasks = this.tickets.filter(x => x.type == Type.TASKS);
        this.bugs = this.tickets.filter(x => x.type == Type.BUGS);
        this.filteredData();
      }
    }, err => {
      console.log(err.error)
    })
  }

  filteredData() {
    this.completedList = this.tickets.filter(x => x.status == StatusType.COMPLETED);
    this.inProgressList = this.tickets.filter(x => x.status == StatusType.IN_PROGRESS);
    this.notStartedList = this.tickets.filter(x => x.status == StatusType.NOT_STARTED);
    if (this.completedList.length == this.tickets.length) {
      this.userColor = this.statusColor[StatusType.COMPLETED];
    }
    else if (this.notStartedList.length == this.tickets.length) {
      this.userColor = this.statusColor[StatusType.NOT_STARTED];
    } else {
      this.userColor = this.statusColor[StatusType.IN_PROGRESS];
    }
  }
}

