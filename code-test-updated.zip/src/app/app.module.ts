import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TicketManagementComponent } from './ticket-management/ticket-management.component';
import { MatTabsModule } from '@angular/material/tabs';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { MatFormFieldModule, MatSelectModule, MatSnackBarModule } from '@angular/material';

@NgModule({
  declarations: [
    AppComponent,
    TicketManagementComponent
  ],
  imports: [
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatSnackBarModule,
    MatSelectModule,
    MatTabsModule,
    BrowserModule,
    NgbModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent],
  exports: [MatTabsModule, MatFormFieldModule, MatSnackBarModule, MatSelectModule]
})
export class AppModule { }
