import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { apiEndPoints } from '../shared/shared.constant';
import { Ticket, Status, User } from './ticket.model';
@Injectable({
  providedIn: 'root'
})
export class TicketManagementService {

  constructor(private http: HttpClient) { }

  getUser(): Observable<User> {
    return this.http.get<User>(environment.apiUrl + apiEndPoints['user'])
    .pipe(catchError(error => of(error)));
  }

  getTickets(): Observable<Ticket[]> {
    return this.http.get<Ticket[]>(environment.apiUrl + apiEndPoints['ticket'])
    .pipe(catchError(error => of(error)));
  }

  getStatus(): Observable<Status[]> {
    return this.http.get<Status[]>(environment.apiUrl + apiEndPoints['status'])
    .pipe(catchError(error => of(error)));
  }

  updateTicket(ticket: Ticket): Observable<Ticket> {
    let options = { headers: new HttpHeaders().set('Content-Type', 'application/json') };
    return this.http.put(environment.apiUrl + apiEndPoints['ticket'] + '/' + ticket.id, ticket, options)
    .pipe(catchError(error => of(error)));
  }
}
