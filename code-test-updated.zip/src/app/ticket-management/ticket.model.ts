export class Ticket {
    id?: number;
    description?: string;
    assignee?: number;
    type?: number;
    status?: number;
    color?: string;
}

export class User {
    id?: number;
    name?: string;
    status?: number
}

export class Status {
    id?: number;
    name?: string;
    friendlyName?: string;
}

export enum Type {
    TASKS = 1,
    BUGS = 2
}

export enum StatusType {
    COMPLETED = 1,
    IN_PROGRESS = 2,
    NOT_STARTED = 3
}