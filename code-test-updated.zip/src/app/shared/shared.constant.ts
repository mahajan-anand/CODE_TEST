export const apiEndPoints = {
    ticket: 'ticket',
    user: 'user',
    type: 'type',
    status: 'status'
}